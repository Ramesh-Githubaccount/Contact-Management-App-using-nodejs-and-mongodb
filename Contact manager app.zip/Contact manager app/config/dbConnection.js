const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGO_LOCAL_URL);
        console.log(`connected To Mongodb Database ${mongoose.connection.host}`);
    } catch (error) {
        console.log(`MongoDB Error ${error}`)
    }
}
module.exports = connectDB;